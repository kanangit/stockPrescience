## The Code

The code is roughly structured in six steps as shown in the figure below. The fundamentals and approach to each stage is briefly explained along the [jupyter notebook file](https://github.com/nilmolne/Text-Mining-The-New-York-Times-Articles/blob/master/Code/HowToUse.ipynb) in the folder.

<p align="center">
  <img src = "Algorithm.png" height = "75%" width = "75%">
</p>
