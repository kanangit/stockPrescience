from .search_api import *

__version__ = "1.0.0"
__author__ = "Champe Barton (@Mchampebartona)"
__all__ = ["articleAPI"]

if __name__ == "__main__":
    print("This module cannot be run on its own. Please use by running ",
          "\"from NYTimesArticleAPInew import articleAPI\"")
    exit(0)
